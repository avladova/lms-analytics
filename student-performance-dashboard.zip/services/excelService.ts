import * as XLSX from 'xlsx';
import { LowWork, SemesterData, PerformanceByTopic, ProblematicTopics, PersonalProgress, AssignmentColumn, ParsedExcelData, Recommendation, GroupStats, DifficultTopic, AcademicRisk, AcademicRiskLevel, StudentGroupPerformance } from '../types';

const TOPIC_ORDER = [
    "Случайные векторы и условные законы распределения",
    "Допустимый объем выборки",
    "Одномерная выборка",
    "Вариационный, статистический ряды и функция распределения",
    "Числовые характеристики объединенной выборки",
    "ДИ для Var(X)",
    "Построение приближенных доверительных интервалов",
    "Проверка гипотезы матожидания нормального закона (ДИ)",
    "Проверка матожидания нормального закона (р-значение)",
    "Проверка гипотезы дисперсии нормального закона (ДИ)",
    "Проверка гипотезы дисперсии нормального закона (р-значение)",
    "Двухвыборочные тесты. Проверка статистических гипотез о равенстве мат ожиданий",
    "Двухвыборочные тесты. Проверка статистических гипотез о равенстве дисперсий",
    "Проверка гипотезы о незначимости коэффициента корреляции",
    "Проверка непараметрических статистических гипотез (о равновероятном распределении: критерий согласия хи-квадрат)",
    "Проверка непараметрических статистических гипотез (критерий согласия хи-квадрат) (заданный вид распределения)",
    "Проверка непараметрических статистических гипотез (критерий согласия хи-квадрат) (нормальность)",
    "Проверка непараметрических статистических гипотез (критерий согласия Лиллиефорса)",
    "Проверка и технологии опровержения статистических гипотез"
];

// --- CONFIGURATION ---

const STUDENT_HASH_KEYWORDS = [
    'hash', 'хэш', 'student hash', 'id', 'идентификатор'
];

const FINAL_GRADE_KEYWORD = 'итоговая оценка';

const WORK_TYPES: { [key: string]: { id: string; name: string; maxScore: number; keywords: string[] } } = {
    HOMEWORK: { id: 'ДСР', name: 'Домашняя работа', maxScore: 10, keywords: ['дср', 'дз'] },
    CONTROL: { id: 'КР', name: 'Контрольная работа', maxScore: 5, keywords: ['кр', 'контрольная'] },
    INDEPENDENT: { id: 'АСР', name: 'Самостоятельная работа', maxScore: 10, keywords: ['аср', 'самостоятельная'] },
};

const typeKeywordsRegex = new RegExp(`(${Object.values(WORK_TYPES).map(t => t.id).join('|')})\\s*\\.*\\s*`, 'i');

// --- HELPER FUNCTIONS ---

const cleanTopicName = (header: string): string => {
    // Removes prefixes like "1. ДСР.", "КР.", etc. to isolate the topic name.
    return header
        .replace(/^\d+\s*\.*\s*/, '') // Removes leading numbers and dots (e.g., "1. ")
        .replace(typeKeywordsRegex, '') // Removes "ДСР", "КР", etc.
        .trim();
};


// --- CORE LOGIC ---

// Step 1: Parse the entire Excel file into a structured format
export const parseExcelFile = async (file: File): Promise<ParsedExcelData> => {
    const data = await file.arrayBuffer();
    const workbook = XLSX.read(data, {type: 'buffer'});
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const jsonData: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

    if (jsonData.length < 2) {
        throw new Error("Excel файл пустой или содержит только заголовок.");
    }

    const headers: string[] = jsonData[0].map(h => String(h));
    
    let studentHashColIndex = -1;
    let studentHashColumnName = '';
    let finalGradeColIndex = -1;
    const assignmentCols: AssignmentColumn[] = [];

    const studentRows = jsonData.slice(1);

    headers.forEach((header, index) => {
        const lowerHeader = header.toLowerCase();

        // Check for student hash column
        if (studentHashColIndex === -1 && STUDENT_HASH_KEYWORDS.some(keyword => lowerHeader.includes(keyword))) {
            studentHashColIndex = index;
            studentHashColumnName = header;
            return;
        }

        // Check for final grade column
        if (finalGradeColIndex === -1 && lowerHeader.includes(FINAL_GRADE_KEYWORD)) {
            finalGradeColIndex = index;
            return;
        }
        
        // Check for assignment columns
        for (const typeKey in WORK_TYPES) {
            const typeInfo = WORK_TYPES[typeKey];
            if (typeInfo.keywords.some(keyword => lowerHeader.includes(keyword))) {
                
                let maxScore = 0;
                studentRows.forEach(row => {
                    if (row) {
                        const score = parseFloat(row[index]);
                        if (!isNaN(score) && score > maxScore) {
                            maxScore = score;
                        }
                    }
                });

                assignmentCols.push({ index, name: header, type: typeInfo.id, maxScore: maxScore > 0 ? maxScore : typeInfo.maxScore });
                return; 
            }
        }
    });


    if (studentHashColIndex === -1) {
        throw new Error("Не удалось найти столбец с хэшами студентов (например, 'хэш', 'id').");
    }
    if (assignmentCols.length === 0) {
        throw new Error("Не удалось найти столбцы с заданиями (например, содержащие 'ДСР', 'КР' или 'АСР').");
    }

    return { jsonData: studentRows, headers, assignmentCols, studentHashColIndex, studentHashColumnName, finalGradeColIndex };
};

// New Step: Calculate Academic Risk
const calculateAcademicRisk = (
    studentScores: { topic: string; score: number; maxScore: number; type: string }[],
    allLowWorks: LowWork[]
): AcademicRisk => {
    let riskScore = 0;
    const contributingFactors: string[] = [];

    // 1. Average score
    const totalPossibleScore = studentScores.reduce((sum, s) => sum + s.maxScore, 0);
    const totalActualScore = studentScores.reduce((sum, s) => sum + s.score, 0);
    const avgPercentage = totalPossibleScore > 0 ? (totalActualScore / totalPossibleScore) * 100 : 100;

    if (avgPercentage < 50) {
        riskScore += 40;
        contributingFactors.push('очень низкий средний балл');
    } else if (avgPercentage < 65) {
        riskScore += 25;
        contributingFactors.push('низкий средний балл');
    } else if (avgPercentage < 75) {
        riskScore += 10;
    }

    // 2. Number of low-score works (<60%)
    const lowWorksCount = allLowWorks.length;
    if (lowWorksCount > 5) {
        riskScore += 30;
        contributingFactors.push('большое количество работ с низким баллом');
    } else if (lowWorksCount > 2) {
        riskScore += 15;
        contributingFactors.push('несколько работ с низким баллом');
    }

    // 3. Zero score works, especially critical ones (KR)
    const zeroScoreWorks = studentScores.filter(s => s.score === 0);
    const zeroScoreControlWorksCount = zeroScoreWorks.filter(s => s.type === 'КР').length;

    if (zeroScoreControlWorksCount > 0) {
        riskScore += zeroScoreControlWorksCount * 20; // Heavier penalty for control works
        contributingFactors.push('невыполненные контрольные работы');
    }

    const zeroScoreOtherWorksCount = zeroScoreWorks.length - zeroScoreControlWorksCount;
    if (zeroScoreOtherWorksCount > 2) {
        riskScore += 10;
        contributingFactors.push('некоторые работы с нулевым баллом');
    }

    // Determine final level and reason
    let level: AcademicRiskLevel;
    if (riskScore >= 90) level = 'Критический';
    else if (riskScore >= 60) level = 'Высокий';
    else if (riskScore >= 30) level = 'Средний';
    else level = 'Низкий';

    let reason = '';
    if (level === 'Низкий') {
        reason = 'Вы демонстрируете стабильные результаты. Продолжайте в том же духе!';
    } else {
        const uniqueFactors = [...new Set(contributingFactors)];
        if (uniqueFactors.length > 0) {
            reason = `Уровень риска определен как "${level.toLowerCase()}" из-за следующих факторов: ${uniqueFactors.join(', ')}.`;
        } else {
            reason = `Ваши результаты требуют внимания. Рекомендуется пересмотреть работы с низкими баллами.`;
        }
    }

    return { level, reason };
};


// Step 2: Process the parsed data for a specific student
export const processStudentData = (studentHashToFind: string, parsedData: ParsedExcelData): SemesterData['all'] => {
    const { jsonData, assignmentCols, studentHashColIndex } = parsedData;

    const studentRow = jsonData.find(row => {
        // Guard against null/empty rows
        if (!row) return false;

        const rawCellValue = row[studentHashColIndex];
        if (rawCellValue === null || rawCellValue === undefined) return false;

        const cellValueStr = String(rawCellValue).trim();
        const studentHashValueStr = studentHashToFind.trim();
        
        if (cellValueStr.toLowerCase() === studentHashValueStr.toLowerCase()) {
            return true;
        }

        if (cellValueStr.endsWith('.0')) {
            if (cellValueStr.slice(0, -2) === studentHashValueStr) {
                return true;
            }
        }
        
        if (studentHashValueStr.endsWith('.0')) {
            if (studentHashValueStr.slice(0, -2) === cellValueStr) {
                return true;
            }
        }
        
        const cellNum = parseFloat(cellValueStr);
        const studentIdNum = parseFloat(studentHashValueStr);
        if (!isNaN(cellNum) && !isNaN(studentIdNum) && cellNum === studentIdNum) {
            return true;
        }

        return false;
    });

    if (!studentRow) {
        throw new Error(`Студент с хэшем "${studentHashToFind}" не найден. Проверьте правильность введенных данных или содержимое файла.`);
    }

    const allLowWorks: LowWork[] = [];
    const studentScores: { topic: string; score: number; maxScore: number; type: string }[] = [];

    assignmentCols.forEach(col => {
        const scoreValue = studentRow[col.index];
        if (scoreValue !== null && scoreValue !== undefined) {
             const score = parseFloat(String(scoreValue));
             if(!isNaN(score)) {
                const percentage = col.maxScore > 0 ? (score / col.maxScore) * 100 : 0;
                const topic = cleanTopicName(col.name);
                const typeInfo = Object.values(WORK_TYPES).find(t => t.id === col.type);

                studentScores.push({ topic, score, maxScore: col.maxScore, type: col.type });

                if (percentage < 60) {
                    allLowWorks.push({
                        hash: `student-${studentHashToFind}-col${col.index}`,
                        topic: topic,
                        type: typeInfo ? typeInfo.name : col.type,
                        score: score,
                        maxScore: col.maxScore,
                        date: new Date().toLocaleDateString('ru-RU')
                    });
                }
            }
        }
    });

    const sortedLowWorks = [...allLowWorks].sort((a, b) => {
        const percentageA = a.maxScore > 0 ? (a.score / a.maxScore) : 0;
        const percentageB = b.maxScore > 0 ? (b.score / b.maxScore) : 0;
        return percentageA - percentageB;
    });

    const zeroScoreWorks = studentScores.filter(work => work.score === 0);

    const zeroScoreWorksByTopic = new Map<string, typeof zeroScoreWorks>();
    zeroScoreWorks.forEach(work => {
        if (!zeroScoreWorksByTopic.has(work.topic)) {
            zeroScoreWorksByTopic.set(work.topic, []);
        }
        zeroScoreWorksByTopic.get(work.topic)!.push(work);
    });

    const recommendations: Recommendation[] = [];
    zeroScoreWorksByTopic.forEach((works, topic) => {
        const workTypeNames = works.map(work => {
            const typeInfo = Object.values(WORK_TYPES).find(t => t.id === work.type);
            return typeInfo ? typeInfo.name : work.type;
        }).filter((value, index, self) => self.indexOf(value) === index);

        const getAccusativeCase = (name: string) => {
            switch(name) {
                case 'Домашняя работа':
                    return 'Домашнюю работу';
                case 'Самостоятельная работа':
                    return 'Самостоятельную работу';
                case 'Контрольная работа':
                    return 'Контрольную работу';
                default:
                    return name;
            }
        };

        let description = '';
        let isCritical = false;

        if (workTypeNames.length > 1) {
            const accusativeTypeNames = workTypeNames.map(getAccusativeCase);
            const typesString = accusativeTypeNames.join(' и ');
            description = `Вы получили 0 баллов за ${typesString} по этой теме. Настоятельно рекомендуется заново изучить материал и повторно прорешать задания.`;
            isCritical = true;
        } else if (workTypeNames.length === 1) {
            const workTypeNameAccusative = getAccusativeCase(workTypeNames[0]);
            description = `Вы получили 0 баллов за ${workTypeNameAccusative}. Настоятельно рекомендуется заново изучить материал по этой теме и повторно прорешать задания.`;
        }

        if (description) {
            recommendations.push({
                title: `Критический результат по теме: "${topic}"`,
                description: description,
                isCritical: isCritical,
            });
        }
    });

    const totalPossibleScore = studentScores.reduce((sum, s) => sum + s.maxScore, 0);
    const totalActualScore = studentScores.reduce((sum, s) => sum + s.score, 0);
    const avgCompletionRate = totalPossibleScore > 0 ? `${((totalActualScore / totalPossibleScore) * 100).toFixed(0)}%` : '0%';
    
    const topicScoresMap = new Map<string, { [type: string]: number[] }>();
    studentScores.forEach(s => {
        if (s.type === 'ДСР' || s.type === 'АСР') {
            const percentage = s.maxScore > 0 ? (s.score / s.maxScore) * 100 : 0;
            if (!topicScoresMap.has(s.topic)) {
                topicScoresMap.set(s.topic, {});
            }
            const topicEntry = topicScoresMap.get(s.topic)!;
            if (!topicEntry[s.type]) {
                topicEntry[s.type] = [];
            }
            topicEntry[s.type].push(percentage);
        }
    });

    const performanceByTopicData: { name: string; [key: string]: string | number }[] = [];
    const uniqueTopics = Array.from(topicScoresMap.keys());

    uniqueTopics.forEach(topic => {
        const entry: { name: string; [key: string]: string | number } = { name: topic };
        const topicData = topicScoresMap.get(topic)!;
        
        const typesToProcess = ['ДСР', 'АСР'];
        typesToProcess.forEach(type => {
            if (topicData[type]) {
                const avg = topicData[type].reduce((a, b) => a + b, 0) / topicData[type].length;
                entry[type] = parseFloat(avg.toFixed(1));
            }
        });
        
        if (Object.keys(entry).length > 1) {
             performanceByTopicData.push(entry);
        }
    });

    performanceByTopicData.sort((a, b) => {
        const indexA = TOPIC_ORDER.indexOf(a.name);
        const indexB = TOPIC_ORDER.indexOf(b.name);
    
        if (indexA !== -1 && indexB !== -1) {
            return indexA - indexB; // Both topics are in the list, sort by index
        }
        if (indexA !== -1) {
            return -1; // Only A is in the list, A comes first
        }
        if (indexB !== -1) {
            return 1; // Only B is in the list, B comes first
        }
        return a.name.localeCompare(b.name); // Neither are in the list, sort alphabetically
    });

    const performanceByTopic: PerformanceByTopic = {
        data: performanceByTopicData,
        types: ['ДСР', 'АСР'],
    };


    const problematicTopics: ProblematicTopics = {
        labels: allLowWorks.map(work => work.topic),
        counts: allLowWorks.map(() => 1),
    };

    const distribution = [0, 0, 0, 0]; // <50, 50-70, 70-85, >85
    studentScores.forEach(s => {
        const percentage = s.maxScore > 0 ? (s.score / s.maxScore) * 100 : 0;
        if (percentage < 50) distribution[0]++;
        else if (percentage < 70) distribution[1]++;
        else if (percentage < 85) distribution[2]++;
        else distribution[3]++;
    });

    const scoresByType: { [type: string]: { scores: number[], maxScores: number[] } } = {};
    studentScores.forEach(s => {
        if (!scoresByType[s.type]) {
            scoresByType[s.type] = { scores: [], maxScores: [] };
        }
        scoresByType[s.type].scores.push(s.score);
        scoresByType[s.type].maxScores.push(s.maxScore);
    });

    const avgCompletionRateByType: SemesterData['all']['avgCompletionRateByType'] = {};
    for (const typeId in scoresByType) {
        const totalScore = scoresByType[typeId].scores.reduce((a, b) => a + b, 0);
        const totalMaxScore = scoresByType[typeId].maxScores.reduce((a, b) => a + b, 0);
        
        const typeInfo = Object.values(WORK_TYPES).find(t => t.id === typeId);
        
        if (totalMaxScore > 0 && typeInfo) {
            avgCompletionRateByType[typeId] = {
                percentage: `${((totalScore / totalMaxScore) * 100).toFixed(0)}%`,
                note: typeInfo.name,
                id: typeInfo.id
            };
        }
    }


    const personalProgress: PersonalProgress = {
        completedWorks: studentScores.length,
        lowScoreCount: allLowWorks.length,
        progressTrend: { labels: [], homeworkScores: [], classworkScores: [] }
    };
    
    const academicRisk = calculateAcademicRisk(studentScores, allLowWorks);

    return {
        avgCompletionRate,
        performanceByTopic,
        lowWorks: sortedLowWorks,
        errorDistribution: distribution,
        problematicTopics,
        personalProgress,
        recommendations,
        avgCompletionRateByType,
        academicRisk
    };
};

// Step 3: Process the parsed data for an entire group (for Teacher View)
export const processGroupData = (parsedData: ParsedExcelData): GroupStats => {
    const { jsonData, assignmentCols, studentHashColIndex, finalGradeColIndex } = parsedData;

    let totalPossibleScore = 0;
    let totalActualScore = 0;
    const scoresByType: { [type: string]: { scores: number[], maxScores: number[] } } = {};
    const topicScoresMap = new Map<string, { [type: string]: number[] }>();
    const topicOverallScores = new Map<string, { scores: number[], maxScores: number[] }>();
    const gradeDistribution = [0, 0, 0, 0]; // "2", "3", "4", "5"
    
    const studentDataMap = new Map<string, { scores: { topic: string; score: number; maxScore: number; type: string }[]; lowWorks: LowWork[] }>();

    jsonData.forEach(studentRow => {
        if (!studentRow || studentRow.length === 0) return;
        
        const studentHash = String(studentRow[studentHashColIndex] || 'Unknown Student');
        if (!studentDataMap.has(studentHash)) {
            studentDataMap.set(studentHash, { scores: [], lowWorks: [] });
        }
        const currentStudentData = studentDataMap.get(studentHash)!;

        // Calculate Grade Distribution if column exists
        if (finalGradeColIndex !== -1) {
            const finalScore = parseFloat(studentRow[finalGradeColIndex]);
            if (!isNaN(finalScore)) {
                if (finalScore <= 49) gradeDistribution[0]++;      // Grade "2"
                else if (finalScore <= 69) gradeDistribution[1]++; // Grade "3"
                else if (finalScore <= 85) gradeDistribution[2]++; // Grade "4"
                else gradeDistribution[3]++;                       // Grade "5"
            }
        }

        assignmentCols.forEach(col => {
            const scoreValue = studentRow[col.index];
            if (scoreValue !== null && scoreValue !== undefined) {
                const score = parseFloat(String(scoreValue));
                if (!isNaN(score)) {
                    totalActualScore += score;
                    totalPossibleScore += col.maxScore;

                    if (!scoresByType[col.type]) scoresByType[col.type] = { scores: [], maxScores: [] };
                    scoresByType[col.type].scores.push(score);
                    scoresByType[col.type].maxScores.push(col.maxScore);
                    
                    const percentage = col.maxScore > 0 ? (score / col.maxScore) * 100 : 0;
                    const topic = cleanTopicName(col.name);
                    
                    currentStudentData.scores.push({ topic, score, maxScore: col.maxScore, type: col.type });
                    
                    if (percentage < 60) {
                        const typeInfo = Object.values(WORK_TYPES).find(t => t.id === col.type);
                        currentStudentData.lowWorks.push({
                             hash: `student-${studentHash}-col${col.index}`,
                             topic: topic,
                             type: typeInfo ? typeInfo.name : col.type,
                             score: score,
                             maxScore: col.maxScore,
                             date: ''
                        });
                    }

                    if (col.type === 'ДСР' || col.type === 'АСР') {
                        if (!topicScoresMap.has(topic)) topicScoresMap.set(topic, {});
                        const topicEntry = topicScoresMap.get(topic)!;
                        if (!topicEntry[col.type]) topicEntry[col.type] = [];
                        topicEntry[col.type].push(percentage);
                    }
                    
                    if (!topicOverallScores.has(topic)) {
                        topicOverallScores.set(topic, { scores: [], maxScores: [] });
                    }
                    topicOverallScores.get(topic)!.scores.push(score);
                    topicOverallScores.get(topic)!.maxScores.push(col.maxScore);
                }
            }
        });
    });

    const overallAvgCompletion = totalPossibleScore > 0 ? `${((totalActualScore / totalPossibleScore) * 100).toFixed(0)}%` : '0%';
    
    const avgCompletionRateByType: GroupStats['avgCompletionRateByType'] = {};
    for (const typeId in scoresByType) {
        const totalScore = scoresByType[typeId].scores.reduce((a, b) => a + b, 0);
        const totalMaxScore = scoresByType[typeId].maxScores.reduce((a, b) => a + b, 0);
        const typeInfo = Object.values(WORK_TYPES).find(t => t.id === typeId);
        if (totalMaxScore > 0 && typeInfo) {
            avgCompletionRateByType[typeId] = {
                percentage: `${((totalScore / totalMaxScore) * 100).toFixed(0)}%`,
                note: typeInfo.name,
                id: typeInfo.id
            };
        }
    }

    const performanceByTopicData: { name: string; [key: string]: string | number }[] = [];
    Array.from(topicScoresMap.keys()).forEach(topic => {
        const entry: { name: string; [key: string]: string | number } = { name: topic };
        const topicData = topicScoresMap.get(topic)!;
        ['ДСР', 'АСР'].forEach(type => {
            if (topicData[type]) {
                const avg = topicData[type].reduce((a, b) => a + b, 0) / topicData[type].length;
                entry[type] = parseFloat(avg.toFixed(1));
            }
        });
        if (Object.keys(entry).length > 1) performanceByTopicData.push(entry);
    });
    
    performanceByTopicData.sort((a, b) => {
        const indexA = TOPIC_ORDER.indexOf(a.name);
        const indexB = TOPIC_ORDER.indexOf(b.name);
    
        if (indexA !== -1 && indexB !== -1) {
            return indexA - indexB; // Both topics are in the list, sort by index
        }
        if (indexA !== -1) {
            return -1; // Only A is in the list, A comes first
        }
        if (indexB !== -1) {
            return 1; // Only B is in the list, B comes first
        }
        return a.name.localeCompare(b.name); // Neither are in the list, sort alphabetically
    });

    const performanceByTopic: PerformanceByTopic = {
        data: performanceByTopicData,
        types: ['ДСР', 'АСР'],
    };
    
    const difficultTopics: DifficultTopic[] = [];
    topicOverallScores.forEach((data, topic) => {
        const totalScore = data.scores.reduce((a, b) => a + b, 0);
        const totalMaxScore = data.maxScores.reduce((a, b) => a + b, 0);
        if (totalMaxScore > 0) {
            const avgPercentage = (totalScore / totalMaxScore) * 100;
            difficultTopics.push({ topic, avgPercentage });
        }
    });
    const sortedDifficultTopics = difficultTopics
        .sort((a, b) => a.avgPercentage - b.avgPercentage)
        .slice(0, 5);

    const studentScores: StudentGroupPerformance[] = [];
    studentDataMap.forEach((data, studentHash) => {
        const academicRisk = calculateAcademicRisk(data.scores, data.lowWorks);
        studentScores.push({
            studentHash,
            lowScoreCount: data.lowWorks.length,
            academicRisk
        });
    });
    
    studentScores.sort((a, b) => b.lowScoreCount - a.lowScoreCount);

    return {
        studentCount: studentDataMap.size,
        overallAvgCompletion,
        avgCompletionRateByType,
        performanceByTopic,
        studentScores,
        difficultTopics: sortedDifficultTopics,
        gradeDistribution,
    };
};