export interface Recommendation {
  title: string;
  description: string;
  isCritical?: boolean;
}

export interface LowWork {
  hash: string;
  topic: string;
  type: string;
  score: number;
  maxScore: number;
  date: string;
}

export interface PerformanceTopicDataPoint {
  name: string;
  [key: string]: string | number;
}

export interface PerformanceByTopic {
  data: PerformanceTopicDataPoint[];
  types: string[];
}


export interface ProblematicTopics {
  labels: string[];
  counts: number[];
}

export interface ProgressTrend {
  labels: string[];
  homeworkScores: number[];
  classworkScores: number[];
}

export interface PersonalProgress {
  completedWorks: number;
  lowScoreCount: number;
  progressTrend: ProgressTrend;
}

export type AcademicRiskLevel = 'Низкий' | 'Средний' | 'Высокий' | 'Критический';

export interface AcademicRisk {
    level: AcademicRiskLevel;
    reason: string;
}

export interface SemesterData {
  all: {
    avgCompletionRate: string;
    performanceByTopic: PerformanceByTopic;
    lowWorks: LowWork[];
    errorDistribution: number[];
    problematicTopics: ProblematicTopics;
    personalProgress: PersonalProgress;
    recommendations: Recommendation[];
    academicRisk: AcademicRisk;
    avgCompletionRateByType: {
        [typeId: string]: {
            percentage: string;
            note: string;
            id: string;
        }
    };
  };
}

export interface SubjectData {
  [semester: string]: SemesterData;
}

export interface MockData {
  [subject: string]: SubjectData;
}


// New types for Excel parsing
export interface AssignmentColumn {
  index: number;
  name: string;
  type: string;
  maxScore: number;
}

export interface ParsedExcelData {
  jsonData: any[][];
  headers: string[];
  assignmentCols: AssignmentColumn[];
  studentHashColIndex: number;
  studentHashColumnName: string;
  finalGradeColIndex: number;
}

export interface DifficultTopic {
    topic: string;
    avgPercentage: number;
}

export interface StudentGroupPerformance {
    studentHash: string;
    lowScoreCount: number;
    academicRisk: AcademicRisk;
}

// New type for Teacher's Group-level dashboard
export interface GroupStats {
    studentCount: number;
    overallAvgCompletion: string;
    avgCompletionRateByType: SemesterData['all']['avgCompletionRateByType'];
    performanceByTopic: PerformanceByTopic;
    studentScores: StudentGroupPerformance[];
    difficultTopics: DifficultTopic[];
    gradeDistribution: number[];
}
