import React, { ReactNode } from 'react';
import { SemesterData, LowWork, Recommendation, PerformanceByTopic, AcademicRisk, AcademicRiskLevel } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Cell, Pie } from 'recharts';

// --- Icon Components ---
const BookOpenIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
    </svg>
);
const ChartBarIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" /></svg>
);
const TableCellsIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M3.375 19.5h17.25m-17.25 0a1.125 1.125 0 01-1.125-1.125V6.375m1.125 13.125A1.125 1.125 0 004.5 18.375h15A1.125 1.125 0 0020.625 19.5m-17.25 0h17.25m-17.25 0h17.25m0 0v-2.25m0 2.25c.621 0 1.125-.504 1.125-1.125V6.375c0-.621-.504-1.125-1.125-1.125m-17.25 0A1.125 1.125 0 014.5 5.25h15A1.125 1.125 0 0120.625 6.375v11.25c0 .621-.504 1.125-1.125 1.125H4.5A1.125 1.125 0 013.375 17.625m17.25-12.375v-2.25m-17.25 2.25v-2.25m17.25 0h-17.25" /></svg>
);
const LightBulbIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189m3.75 7.478a12.06 12.06 0 01-4.5 0m3.75 2.311a7.5 7.5 0 01-7.5 0c-1.451 0-2.716.62-3.682 1.58M12 21a7.5 7.5 0 01-7.5-7.5c0-1.451.62-2.716 1.58-3.682m11.84 5.262A7.5 7.5 0 0112 21M12 4.5a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0V5.25A.75.75 0 0112 4.5zM18.75 8.25a.75.75 0 01.75-.75h2.25a.75.75 0 010 1.5H19.5a.75.75 0 01-.75-.75zM3 9a.75.75 0 01.75-.75h2.25a.75.75 0 010 1.5H3.75A.75.75 0 013 9zm15.75-3.75a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0V6a.75.75 0 01.75-.75zM4.5 15.75a.75.75 0 01.75-.75h2.25a.75.75 0 010 1.5H5.25a.75.75 0 01-.75-.75z" /></svg>
);
const ExclamationCircleIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
    </svg>
);
const ChartPieIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6a7.5 7.5 0 100 15 7.5 7.5 0 000-15zm0 0v7.5m0 0h7.5m-7.5 0L3 16.5m7.5-7.5L7.5 3m3 3l3.375-3.375M10.5 6a2.25 2.25 0 00-2.25 2.25v.875a.75.75 0 00.75.75h3.5a.75.75 0 00.75-.75v-.875a2.25 2.25 0 00-2.25-2.25z" />
    </svg>
);
const ShieldExclamationIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
    </svg>
);


// --- Reusable UI Components ---
const Widget: React.FC<{ title: string; icon?: React.FC<{className:string}>; children: ReactNode; className?: string }> = ({ title, icon: Icon, children, className = '' }) => (
    <div className={`bg-white p-4 sm:p-6 rounded-2xl shadow-sm flex flex-col ${className}`}>
        <div className="flex items-center mb-4 shrink-0">
            {Icon && <Icon className="w-6 h-6 mr-3 text-primary-500" />}
            <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        </div>
        <div className="flex-grow">{children}</div>
    </div>
);

const StatCard: React.FC<{ title: string; value: string; note: string; riskLevel?: AcademicRiskLevel }> = ({ title, value, note, riskLevel }) => {
    const getRiskColor = () => {
        if (!riskLevel) return 'text-gray-900';
        switch (riskLevel) {
            case 'Критический': return 'text-red-600';
            case 'Высокий': return 'text-orange-600';
            case 'Средний': return 'text-amber-600';
            case 'Низкий': return 'text-green-600';
            default: return 'text-gray-900';
        }
    };
    
    return (
        <div className="p-5 bg-white rounded-2xl shadow-sm">
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <p className={`mt-1 text-3xl font-bold ${getRiskColor()}`}>{value}</p>
            <p className="mt-1 text-sm text-gray-500">{note}</p>
        </div>
    );
};

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="p-3 bg-white border border-gray-200 rounded-lg shadow-sm">
          <p className="font-semibold text-gray-800">{label}</p>
          {payload.map((pld: any) => (
            <p key={pld.dataKey} style={{ color: pld.color }} className="text-sm">
              {`${pld.name}: ${pld.value}%`}
            </p>
          ))}
        </div>
      );
    }
    return null;
};

// --- Dashboard Widgets ---

const AcademicRiskWidget: React.FC<{ risk: AcademicRisk }> = ({ risk }) => {
    const getRiskColors = (level: AcademicRiskLevel): { bg: string; text: string; border: string; } => {
        switch (level) {
            case 'Критический': return { bg: 'bg-red-50', text: 'text-red-800', border: 'border-red-200' };
            case 'Высокий': return { bg: 'bg-orange-50', text: 'text-orange-800', border: 'border-orange-200' };
            case 'Средний': return { bg: 'bg-amber-50', text: 'text-amber-800', border: 'border-amber-200' };
            case 'Низкий': return { bg: 'bg-green-50', text: 'text-green-800', border: 'border-green-200' };
            default: return { bg: 'bg-gray-50', text: 'text-gray-800', border: 'border-gray-200' };
        }
    };

    const colors = getRiskColors(risk.level);

    return (
        <div className={`p-5 rounded-2xl shadow-sm border ${colors.bg} ${colors.border}`}>
            <div className="flex items-start">
                <div className={`p-2 rounded-full mr-4 ${colors.text} bg-white`}>
                    <ShieldExclamationIcon className="w-8 h-8"/>
                </div>
                <div>
                    <h3 className="text-sm font-semibold text-gray-600">Академический риск</h3>
                    <p className={`text-2xl font-bold ${colors.text}`}>{risk.level.toUpperCase()}</p>
                    <p className={`mt-2 text-sm ${colors.text}`}>{risk.reason}</p>
                </div>
            </div>
        </div>
    );
};

const RecommendationsWidget: React.FC<{ recommendations: Recommendation[] }> = ({ recommendations }) => (
    <Widget title="Рекомендации для изучения" icon={LightBulbIcon}>
        {recommendations.length > 0 ? (
            <ul className="space-y-4">
                {recommendations.map((rec, index) => (
                    <li 
                        key={index} 
                        className={`p-4 transition-all duration-300 rounded-lg ${
                            rec.isCritical 
                            ? 'bg-red-100 hover:bg-red-200 border border-red-200' 
                            : 'bg-blue-50 hover:bg-blue-100'
                        }`}
                    >
                        <p className={`font-semibold ${rec.isCritical ? 'text-red-800' : 'text-primary-800'}`}>{rec.title}</p>
                        <p className={`mt-1 text-sm ${rec.isCritical ? 'text-red-700' : 'text-primary-700'}`}>{rec.description}</p>
                    </li>
                ))}
            </ul>
        ) : (
            <div className="flex items-center justify-center h-full text-center text-gray-500">
                <p>Отличная работа! <br/> Нет работ с низкими баллами.</p>
            </div>
        )}
    </Widget>
);

const LowWorksTable: React.FC<{ works: LowWork[] }> = ({ works }) => (
    <Widget title="Работы с низким баллом" icon={TableCellsIcon}>
         <div className="overflow-x-auto">
            {works.length > 0 ? (
                <table className="min-w-full text-sm text-left text-gray-700">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-4 py-3 font-medium text-gray-600">Тема</th>
                            <th className="px-4 py-3 font-medium text-gray-600">Тип</th>
                            <th className="px-4 py-3 font-medium text-gray-600 text-right">Балл</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {works.map(work => (
                            <tr key={work.hash} className={work.score === 0 ? 'bg-red-50' : ''}>
                                <td className="px-4 py-3 font-medium">{work.topic}</td>
                                <td className="px-4 py-3 text-gray-600">{work.type}</td>
                                <td className={`px-4 py-3 font-mono text-right ${work.score === 0 ? 'text-red-600 font-bold' : ''}`}>
                                    {work.score === 0 && <ExclamationCircleIcon className="w-5 h-5 inline-block mr-1 text-red-500" />}
                                    {`${work.score} / ${work.maxScore}`}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <div className="flex items-center justify-center h-48 text-center text-gray-500">
                     <p>Нет работ с низкими баллами для отображения.</p>
                </div>
            )}
        </div>
    </Widget>
);

const PerformanceChart: React.FC<{ data: PerformanceByTopic }> = ({ data }) => {
    const typeFullNames: { [key: string]: string } = {
        'ДСР': 'Дом. работа (ДСР)',
        'АСР': 'Сам. работа (АСР)'
    };
    const COLORS = ['#3b82f6', '#10b981', '#ef4444', '#f97316'];

    return (
        <Widget title="Динамика успеваемости по темам" icon={ChartBarIcon}>
            <ResponsiveContainer width="100%" height={600}>
                <LineChart data={data.data} margin={{ top: 5, right: 20, left: -10, bottom: 150 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-60} textAnchor="end" interval={0} />
                    <YAxis unit="%" domain={[0, 100]} tick={{ fontSize: 12 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend verticalAlign="top" wrapperStyle={{ paddingBottom: '20px' }}/>
                    {data.types.map((type, index) => (
                        <Line
                            key={type}
                            type="monotone"
                            dataKey={type}
                            name={typeFullNames[type] || type}
                            stroke={COLORS[index % COLORS.length]}
                            strokeWidth={2}
                            activeDot={{ r: 6 }}
                            dot={{r: 4}}
                        />
                    ))}
                </LineChart>
            </ResponsiveContainer>
        </Widget>
    );
};

const ScoreDistributionChart: React.FC<{data: number[]}> = ({data}) => {
    const chartData = [
        { name: '< 50%', value: data[0] },
        { name: '50-70%', value: data[1] },
        { name: '70-85%', value: data[2] },
        { name: '> 85%', value: data[3] },
      ].filter(d => d.value > 0);
      
    const COLORS = ['#ef4444', '#f97316', '#eab308', '#22c55e'];

    const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
        if (percent < 0.05) return null;
        const RADIAN = Math.PI / 180;
        const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
        const x = cx + radius * Math.cos(-midAngle * RADIAN);
        const y = cy + radius * Math.sin(-midAngle * RADIAN);
      
        return (
          <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central" className="text-xs font-medium">
            {`${(percent * 100).toFixed(0)}%`}
          </text>
        );
      };

    return (
        <Widget title="Распределение оценок" icon={ChartPieIcon}>
            {chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                        <Pie
                            data={chartData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={renderCustomizedLabel}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                            stroke="#fff"
                            strokeWidth={2}
                        >
                            {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip formatter={(value, name) => [`${value} работ`, name]}/>
                        <Legend iconSize={10} wrapperStyle={{fontSize: "12px", paddingTop: "20px"}}/>
                    </PieChart>
                </ResponsiveContainer>
            ) : (
                <div className="flex items-center justify-center h-full text-center text-gray-500">
                    <p>Нет данных для отображения распределения.</p>
                </div>
            )}
        </Widget>
    )
}


interface StudentAnalyticsViewProps {
    studentData: SemesterData['all'];
    studentHash: string;
}

const StudentAnalyticsView: React.FC<StudentAnalyticsViewProps> = ({ studentData, studentHash }) => {
    const { avgCompletionRate, avgCompletionRateByType, recommendations, lowWorks, performanceByTopic, errorDistribution, academicRisk } = studentData;
    return (
         <>
            <div className='mb-6'>
                <AcademicRiskWidget risk={academicRisk} />
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mb-6">
                <StatCard 
                    title="Средний % выполнения" 
                    value={avgCompletionRate} 
                    note="По всем работам" 
                    riskLevel={academicRisk.level} 
                />
                {Object.values(avgCompletionRateByType).map((stat: { id: string; percentage: string; note: string; }) => (
                    <StatCard key={stat.id} title={`Средний % (${stat.id})`} value={stat.percentage} note={stat.note} />
                ))}
            </div>
            
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                <div className="xl:col-span-2 space-y-6">
                    <PerformanceChart data={performanceByTopic} />
                    <LowWorksTable works={lowWorks} />
                </div>
                
                <div className="space-y-6">
                    <RecommendationsWidget recommendations={recommendations} />
                    <ScoreDistributionChart data={errorDistribution}/>
                </div>
            </div>
         </>
    );
};

export default StudentAnalyticsView;