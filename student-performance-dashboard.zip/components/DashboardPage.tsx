import React, { useState, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { SemesterData, ParsedExcelData } from '../types';
import { processStudentData } from '../services/excelService';
import StudentAnalyticsView from './StudentAnalyticsView';

// --- Icon Components ---
const ArrowLeftIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" /></svg>
);
const BookOpenIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
    </svg>
);
const ExclamationTriangleIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
    </svg>
);
const UserCircleIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);

// --- Main Page Component ---
const DashboardPage: React.FC = () => {
    const location = useLocation();
    const navigate = useNavigate();
    
    const { groupData, groupName } = location.state as { groupData: ParsedExcelData, groupName: string } || {};

    const [activeStudentData, setActiveStudentData] = useState<SemesterData['all'] | null>(null);
    const [studentHash, setStudentHash] = useState('');
    const [studentFound, setStudentFound] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    if (!groupData) {
        return (
            <div className="flex flex-col items-center justify-center h-screen bg-slate-100">
                <ExclamationTriangleIcon className="w-16 h-16 text-amber-500"/>
                <h2 className="mt-4 text-2xl font-bold text-gray-800">Ошибка</h2>
                <p className="mt-2 text-gray-600">Данные о группе не найдены. Пожалуйста, вернитесь и выберите группу.</p>
                <button onClick={() => navigate('/')} className="mt-6 px-6 py-3 font-medium text-white transition-colors duration-200 rounded-lg cursor-pointer bg-primary-600 hover:bg-primary-700">
                    Вернуться к выбору группы
                </button>
            </div>
        )
    }

    const handleStudentLogin = useCallback(async (e: React.FormEvent) => {
        e.preventDefault();
        if (!studentHash || !groupData) return;

        setLoading(true);
        setError(null);
        try {
            const studentData = processStudentData(studentHash, groupData);
            setActiveStudentData(studentData);
            setStudentFound(true);
        } catch (err: any) {
            setError(err.message);
            setActiveStudentData(null);
            setStudentFound(false);
        } finally {
            setLoading(false);
        }
    }, [studentHash, groupData]);

    const handleChangeStudent = useCallback(() => {
        setActiveStudentData(null);
        setStudentFound(false);
        setStudentHash('');
        setError(null);
    }, []);

    const renderContent = () => {
        if (loading) {
            return (
                <div className="flex flex-col items-center justify-center h-screen">
                    <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-primary-500"></div>
                    <p className="mt-4 text-lg text-gray-600">Обработка данных...</p>
                </div>
            );
        }
        
        if (!studentFound) {
             return (
                <div className="flex items-center justify-center min-h-screen bg-slate-100">
                    <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-2xl shadow-lg">
                        <div className="text-center">
                            <UserCircleIcon className="w-16 h-16 mx-auto text-primary-500"/>
                            <h2 className="mt-4 text-2xl font-bold text-gray-800">Поиск студента</h2>
                            <p className="mt-2 text-sm text-gray-600">Выбрана группа: <span className="font-semibold">{groupName}</span>. Введите ваш хэш.</p>
                        </div>
                        {error && <div className="p-3 text-sm text-red-700 bg-red-100 rounded-lg"><ExclamationTriangleIcon className="inline w-5 h-5 mr-2"/>{error}</div>}
                        <form className="space-y-6" onSubmit={handleStudentLogin}>
                             <div>
                                <label htmlFor="student-hash" className="sr-only">Хэш</label>
                                <input
                                    id="student-hash"
                                    name="student-hash"
                                    type="text"
                                    required
                                    className="relative block w-full px-4 py-3 text-gray-900 placeholder-gray-500 border border-gray-300 rounded-md appearance-none focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                                    placeholder="Введите ваш хэш"
                                    value={studentHash}
                                    onChange={(e) => setStudentHash(e.target.value)}
                                />
                            </div>
                            <div className="flex items-center justify-between gap-4">
                               <button type="button" onClick={() => navigate('/')} className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                                    Выбрать другую группу
                                </button>
                                <button type="submit" className="flex-grow px-4 py-2 text-sm font-medium text-white rounded-md bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                                    Показать данные
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            );
        }

        if (activeStudentData) {
            return (
                 <div className="min-h-screen bg-slate-100">
                    <header className="flex items-center justify-between p-4 bg-white border-b border-gray-200 shadow-sm">
                        <div className="flex items-center">
                            <BookOpenIcon className="w-8 h-8 text-primary-600"/>
                            <h1 className="ml-3 text-xl font-bold text-gray-800">Панель успеваемости студента: <span className="font-medium text-primary-700">{studentHash}</span></h1>
                        </div>
                        <div className="flex items-center gap-4">
                            <button onClick={handleChangeStudent} className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">Сменить студента</button>
                            <button onClick={() => navigate('/')} className="flex items-center px-4 py-2 text-sm font-medium text-white rounded-md bg-primary-600 hover:bg-primary-700">
                                <ArrowLeftIcon className="w-5 h-5 mr-2" />
                                К выбору группы
                            </button>
                        </div>
                    </header>
                    <main className="p-4 sm:p-6 lg:p-8">
                        <StudentAnalyticsView studentData={activeStudentData} studentHash={studentHash} />
                    </main>
                 </div>
            );
        }
        
        return null;
    };

    return <div className="bg-slate-50">{renderContent()}</div>;
};

export default DashboardPage;