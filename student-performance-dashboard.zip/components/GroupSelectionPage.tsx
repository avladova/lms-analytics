
import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ParsedExcelData } from '../types';

interface GroupSelectionPageProps {
  files: { [fileName: string]: ParsedExcelData };
}

const AcademicCapIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path d="M12 14.25c-2.43 0-4.63.62-6.5 1.69v3.81c0 .48.46.93 1.05.93h10.9c.59 0 1.05-.45 1.05-.93v-3.81c-1.87-1.07-4.07-1.69-6.5-1.69z" /><path strokeLinecap="round" strokeLinejoin="round" d="M12 14.25L12 4.5m0 9.75l-2.5-1.42M12 4.5L14.5 3M12 4.5L9.5 3M12 14.25l2.5-1.42M12 14.25L12 21m-4-10.5l4 2.25m-4-2.25l-4-2.25m8 4.5l4-2.25M12 21l4-2.25m-8-4.5l-4 2.25m8 4.5l-4 2.25" /></svg>
);

const UserGroupIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.5-2.962a3.75 3.75 0 015.962 0zM12 6.75a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM12 18.75a9.094 9.094 0 00-3.742-.479 3 3 0 00-4.682 2.72M6.75 18.75a9.094 9.094 0 01-3.742-.479 3 3 0 01-4.682 2.72" />
    </svg>
);


const GroupSelectionPage: React.FC<GroupSelectionPageProps> = ({ files }) => {
    const navigate = useNavigate();
    const fileNames = Object.keys(files);

    const handleSelectGroup = (groupName: string) => {
        const groupData = files[groupName];
        navigate('/student/dashboard', { state: { groupData, groupName } });
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-slate-100 p-4">
             <div className="w-full max-w-2xl p-8 space-y-8 bg-white rounded-2xl shadow-lg">
                <div className="text-center">
                    <UserGroupIcon className="w-16 h-16 mx-auto text-primary-500"/>
                    <h1 className="mt-4 text-3xl font-bold text-gray-900">Портал студента</h1>
                    <p className="mt-2 text-gray-600">Выберите свою учебную группу, чтобы продолжить.</p>
                </div>
                
                <div className="space-y-3">
                    {fileNames.length > 0 ? (
                        fileNames.map(name => (
                            <button 
                                key={name} 
                                onClick={() => handleSelectGroup(name)}
                                className="w-full px-5 py-4 text-left font-semibold text-primary-800 bg-primary-50 rounded-lg hover:bg-primary-100 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary-500"
                            >
                                {name}
                            </button>
                        ))
                    ) : (
                        <div className="text-center py-8 px-4 border-2 border-dashed border-gray-300 rounded-lg">
                            <p className="text-gray-500">В данный момент нет доступных групп.</p>
                            <p className="text-sm text-gray-400 mt-1">Пожалуйста, подождите, пока ваш преподаватель загрузит файл.</p>
                        </div>
                    )}
                </div>

                <div className="pt-4 text-center border-t border-gray-200">
                    <Link to="/login" className="flex items-center justify-center gap-2 text-sm font-medium text-primary-600 hover:text-primary-500">
                        <AcademicCapIcon className="w-5 h-5" />
                        Войти как преподаватель
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default GroupSelectionPage;
