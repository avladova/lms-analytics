import React, { useState, useCallback, ReactNode, useMemo } from 'react';
import { ParsedExcelData, GroupStats, PerformanceByTopic, DifficultTopic, SemesterData, StudentGroupPerformance, AcademicRiskLevel } from '../types';
import { parseExcelFile, processGroupData, processStudentData } from '../services/excelService';
import StudentAnalyticsView from './StudentAnalyticsView';

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

// --- Icon Components ---
const LogOutIcon: React.FC<{className: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9" />
  </svg>
);
const DocumentArrowUpIcon: React.FC<{className: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m.75 12l3 3m0 0l3-3m-3 3v-6m-1.5-9H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
  </svg>
);
const UsersIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.5-2.962a3.75 3.75 0 015.962 0zM12 6.75a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM12 18.75a9.094 9.094 0 00-3.742-.479 3 3 0 00-4.682 2.72M6.75 18.75a9.094 9.094 0 01-3.742-.479 3 3 0 01-4.682 2.72" /></svg>
);
const ChartBarIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" /></svg>
);
const AcademicCapIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path d="M12 14.25c-2.43 0-4.63.62-6.5 1.69v3.81c0 .48.46.93 1.05.93h10.9c.59 0 1.05-.45 1.05-.93v-3.81c-1.87-1.07-4.07-1.69-6.5-1.69z" /><path strokeLinecap="round" strokeLinejoin="round" d="M12 14.25L12 4.5m0 9.75l-2.5-1.42M12 4.5L14.5 3M12 4.5L9.5 3M12 14.25l2.5-1.42M12 14.25L12 21m-4-10.5l4 2.25m-4-2.25l-4-2.25m8 4.5l4-2.25M12 21l4-2.25m-8-4.5l-4 2.25m8 4.5l-4 2.25" /></svg>
);
const ChartPieIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6a7.5 7.5 0 100 15 7.5 7.5 0 000-15zm0 0v7.5m0 0h7.5m-7.5 0L3 16.5m7.5-7.5L7.5 3m3 3l3.375-3.375M10.5 6a2.25 2.25 0 00-2.25 2.25v.875a.75.75 0 00.75.75h3.5a.75.75 0 00.75-.75v-.875a2.25 2.25 0 00-2.25-2.25z" />
    </svg>
);
const XMarkIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);
const ChevronUpDownIcon: React.FC<{className: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9" /></svg>
);


interface TeacherDashboardPageProps {
    onLogout: () => void;
    files: { [fileName: string]: ParsedExcelData };
    addFile: (name: string, data: ParsedExcelData) => void;
}

// --- Reusable UI Components ---
const Widget: React.FC<{ title: string; icon?: React.FC<{className:string}>; children: ReactNode; className?: string }> = ({ title, icon: Icon, children, className = '' }) => (
    <div className={`bg-white p-4 sm:p-6 rounded-2xl shadow-sm flex flex-col ${className}`}>
        <div className="flex items-center mb-4 shrink-0">
            {Icon && <Icon className="w-6 h-6 mr-3 text-primary-500" />}
            <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        </div>
        <div className="flex-grow">{children}</div>
    </div>
);

const StatCard: React.FC<{ title: string; value: string; note: string; }> = ({ title, value, note }) => (
    <div className="p-5 bg-white rounded-2xl shadow-sm">
        <p className="text-sm font-medium text-gray-500">{title}</p>
        <p className="mt-1 text-3xl font-bold text-gray-900">{value}</p>
        <p className="mt-1 text-sm text-gray-500">{note}</p>
    </div>
);

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="p-3 bg-white border border-gray-200 rounded-lg shadow-sm">
          <p className="font-semibold text-gray-800">{label}</p>
          {payload.map((pld: any) => (
            <p key={pld.dataKey} style={{ color: pld.color }} className="text-sm">
              {`${pld.name}: ${pld.value}%`}
            </p>
          ))}
        </div>
      );
    }
    return null;
};

// --- Widgets for Teacher Dashboard ---
const PerformanceChart: React.FC<{ data: PerformanceByTopic }> = ({ data }) => {
    const typeFullNames: { [key: string]: string } = {
        'ДСР': 'Дом. работа (ДСР)',
        'АСР': 'Сам. работа (АСР)'
    };
    const COLORS = ['#3b82f6', '#10b981', '#ef4444', '#f97316'];

    return (
        <Widget title="Динамика успеваемости по темам (в среднем по группе)" icon={ChartBarIcon}>
            <ResponsiveContainer width="100%" height={600}>
                <LineChart data={data.data} margin={{ top: 5, right: 20, left: -10, bottom: 150 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-60} textAnchor="end" interval={0} />
                    <YAxis unit="%" domain={[0, 100]} tick={{ fontSize: 12 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend verticalAlign="top" wrapperStyle={{ paddingBottom: '20px' }}/>
                    {data.types.map((type, index) => (
                        <Line
                            key={type}
                            type="monotone"
                            dataKey={type}
                            name={typeFullNames[type] || type}
                            stroke={COLORS[index % COLORS.length]}
                            strokeWidth={2}
                            activeDot={{ r: 6 }}
                            dot={{r: 4}}
                        />
                    ))}
                </LineChart>
            </ResponsiveContainer>
        </Widget>
    );
};

const StudentOverviewWidget: React.FC<{students: StudentGroupPerformance[], onSelectStudent: (studentHash: string) => void}> = ({students, onSelectStudent}) => {
    type SortKey = 'studentHash' | 'lowScoreCount' | 'academicRisk';
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: 'ascending' | 'descending' }>({ key: 'lowScoreCount', direction: 'descending' });
    
    const riskLevelOrder: Record<AcademicRiskLevel, number> = { 'Низкий': 0, 'Средний': 1, 'Высокий': 2, 'Критический': 3 };

    const sortedStudents = useMemo(() => {
        let sortableItems = [...students];
        if (sortConfig.key) {
            sortableItems.sort((a, b) => {
                let aValue: any;
                let bValue: any;

                if (sortConfig.key === 'academicRisk') {
                    aValue = riskLevelOrder[a.academicRisk.level];
                    bValue = riskLevelOrder[b.academicRisk.level];
                } else {
                    aValue = a[sortConfig.key];
                    bValue = b[sortConfig.key];
                }

                if (aValue < bValue) {
                    return sortConfig.direction === 'ascending' ? -1 : 1;
                }
                if (aValue > bValue) {
                    return sortConfig.direction === 'ascending' ? 1 : -1;
                }
                return 0;
            });
        }
        return sortableItems;
    }, [students, sortConfig]);
    
    const requestSort = (key: SortKey) => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };
    
    const getRiskBadgeClass = (level: AcademicRiskLevel) => {
        switch (level) {
            case 'Критический': return 'bg-red-100 text-red-800';
            case 'Высокий': return 'bg-orange-100 text-orange-800';
            case 'Средний': return 'bg-amber-100 text-amber-800';
            case 'Низкий': return 'bg-green-100 text-green-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    const SortableHeader: React.FC<{ sortKey: SortKey, title: string, className?: string }> = ({ sortKey, title, className }) => (
        <th className={`px-4 py-3 font-medium text-gray-600 ${className || ''}`}>
            <button onClick={() => requestSort(sortKey)} className="flex items-center gap-2 hover:text-gray-900">
                {title}
                <ChevronUpDownIcon className="w-4 h-4 text-gray-400" />
            </button>
        </th>
    );

    return (
        <Widget title="Обзор успеваемости студентов" icon={UsersIcon} className="h-full">
            <div className="overflow-auto">
                {students.length > 0 ? (
                     <table className="min-w-full text-sm text-left text-gray-700">
                        <thead className="bg-gray-50 sticky top-0">
                            <tr>
                                <SortableHeader sortKey="studentHash" title="Хэш студента" />
                                <SortableHeader sortKey="lowScoreCount" title="Работы с низким баллом" className="text-right"/>
                                <SortableHeader sortKey="academicRisk" title="Уровень риска" className="text-center"/>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {sortedStudents.map(student => (
                                <tr key={student.studentHash} className="hover:bg-gray-50">
                                    <td className="px-4 py-3 font-medium">
                                        <button onClick={() => onSelectStudent(student.studentHash)} className="text-primary-600 hover:text-primary-700 hover:underline text-left w-full">
                                            {student.studentHash}
                                        </button>
                                    </td>
                                    <td className="px-4 py-3 font-mono text-right font-semibold text-red-600">{student.lowScoreCount > 0 ? student.lowScoreCount : '—'}</td>
                                    <td className="px-4 py-3 text-center">
                                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getRiskBadgeClass(student.academicRisk.level)}`}>
                                            {student.academicRisk.level}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div className="flex items-center justify-center h-48 text-center text-gray-500">
                         <p>Нет данных о студентах в этой группе.</p>
                    </div>
                )}
            </div>
        </Widget>
    );
};


const DifficultTopicsWidget: React.FC<{topics: DifficultTopic[]}> = ({topics}) => (
    <Widget title="Сложные для студентов темы" icon={AcademicCapIcon}>
        <div className="overflow-x-auto">
            {topics.length > 0 ? (
                 <table className="min-w-full text-sm text-left text-gray-700">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-4 py-3 font-medium text-gray-600">Тема</th>
                            <th className="px-4 py-3 font-medium text-gray-600 text-right">Средний % выполнения</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {topics.map(item => (
                            <tr key={item.topic}>
                                <td className="px-4 py-3 font-medium">{item.topic}</td>
                                <td className="px-4 py-3 font-mono text-right font-semibold text-amber-600">{`${item.avgPercentage.toFixed(0)}%`}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <div className="flex items-center justify-center h-48 text-center text-gray-500">
                     <p>Не удалось определить сложные темы. Возможно, данных недостаточно.</p>
                </div>
            )}
        </div>
    </Widget>
);

const GradeDistributionChart: React.FC<{data: number[]}> = ({data}) => {
    const chartData = [
        { name: "Оценка '2'", value: data[0] },
        { name: "Оценка '3'", value: data[1] },
        { name: "Оценка '4'", value: data[2] },
        { name: "Оценка '5'", value: data[3] },
      ].filter(d => d.value > 0);
      
    const COLORS = ['#ef4444', '#f97316', '#eab308', '#22c55e'];
    const total = data.reduce((sum, val) => sum + val, 0);

    return (
        <Widget title="Итоговые оценки по группе" icon={ChartPieIcon}>
            {total > 0 && chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                        <Pie
                            data={chartData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                            stroke="#fff"
                            strokeWidth={2}
                        >
                            {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip formatter={(value, name) => [`${value} студент(ов)`, name]}/>
                        <Legend iconSize={10} wrapperStyle={{fontSize: "12px", paddingTop: "20px"}}/>
                    </PieChart>
                </ResponsiveContainer>
            ) : (
                <div className="flex items-center justify-center h-full text-center text-gray-500">
                    <p>Нет данных для отображения. Убедитесь, что в файле есть столбец "итоговая оценка".</p>
                </div>
            )}
        </Widget>
    )
}


// --- Main Page Component ---
const TeacherDashboardPage: React.FC<TeacherDashboardPageProps> = ({ onLogout, files, addFile }) => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
    const [groupStats, setGroupStats] = useState<GroupStats | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedStudentHash, setSelectedStudentHash] = useState<string | null>(null);
    const [modalStudentData, setModalStudentData] = useState<SemesterData['all'] | null>(null);

    const handleFileChange = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        setLoading(true);
        setError(null);
        try {
            const parsedData = await parseExcelFile(file);
            addFile(file.name, parsedData);
            handleSelectGroup(file.name, parsedData);
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
            event.target.value = '';
        }
    }, [addFile]);
    
    const handleSelectGroup = (groupName: string, fileData?: ParsedExcelData) => {
        setLoading(true);
        setError(null);
        try {
            const dataToProcess = fileData || files[groupName];
            if (!dataToProcess) {
                throw new Error("File data not found.");
            }
            const stats = processGroupData(dataToProcess);
            setGroupStats(stats);
            setSelectedGroup(groupName);
        } catch (err: any) {
            setError(err.message);
            setGroupStats(null);
        } finally {
            setLoading(false);
        }
    }

    const handleSelectStudentForModal = useCallback((studentHash: string) => {
        const fileData = files[selectedGroup!];
        if (fileData) {
            try {
                const studentData = processStudentData(studentHash, fileData);
                setModalStudentData(studentData);
                setSelectedStudentHash(studentHash);
                setIsModalOpen(true);
            } catch (err: any) {
                setError(`Не удалось загрузить данные для студента: ${err.message}`);
            }
        }
    }, [files, selectedGroup]);
    
    const closeModal = () => {
        setIsModalOpen(false);
        setSelectedStudentHash(null);
        setModalStudentData(null);
    }

    return (
        <div className="min-h-screen bg-slate-100">
            <header className="flex items-center justify-between p-4 bg-white border-b border-gray-200 shadow-sm sticky top-0 z-20">
                <div className="flex items-center">
                    <AcademicCapIcon className="w-8 h-8 text-primary-600"/>
                    <h1 className="ml-3 text-xl font-bold text-gray-800">Панель преподавателя</h1>
                </div>
                <button onClick={onLogout} className="flex items-center px-4 py-2 text-sm font-medium text-white rounded-md bg-primary-600 hover:bg-primary-700">
                    <LogOutIcon className="w-5 h-5 mr-2" />
                    Выход
                </button>
            </header>

            <div className="flex">
                {/* Sidebar */}
                <aside className="w-1/4 max-w-sm p-6 bg-white border-r border-gray-200 h-screen sticky top-[73px]">
                    <h2 className="text-lg font-semibold text-gray-800 mb-4">Группы студентов</h2>
                    
                    <div>
                        <label htmlFor="file-upload" className="relative w-full inline-block px-4 py-3 text-sm font-medium text-white transition-colors duration-200 rounded-lg cursor-pointer bg-primary-600 hover:bg-primary-700 text-center">
                             <DocumentArrowUpIcon className="w-5 h-5 mr-2 inline-block"/>
                            <span>Загрузить новую группу</span>
                            <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept=".xlsx, .xls"/>
                        </label>
                         {loading && <p className="text-sm text-center mt-2 text-gray-600">Загрузка...</p>}
                         {error && !isModalOpen && <p className="text-xs text-center mt-2 text-red-600">{error}</p>}
                    </div>
                    
                    <div className="mt-6 space-y-2">
                        {Object.keys(files).length === 0 ? (
                            <p className="text-sm text-gray-500 text-center py-4">Нет загруженных групп.</p>
                        ) : (
                            Object.keys(files).map(fileName => (
                                <button key={fileName} onClick={() => handleSelectGroup(fileName)} 
                                className={`w-full text-left px-4 py-3 rounded-lg text-sm transition-colors ${selectedGroup === fileName ? 'bg-primary-100 text-primary-800 font-semibold' : 'text-gray-700 hover:bg-slate-100'}`}>
                                    {fileName}
                                </button>
                            ))
                        )}
                    </div>
                </aside>

                {/* Main Content */}
                <main className="flex-1 p-8">
                    {!selectedGroup ? (
                        <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 bg-slate-50 rounded-lg">
                           <UsersIcon className="w-16 h-16 text-gray-400"/>
                           <h2 className="mt-4 text-xl font-semibold text-gray-700">Выберите группу</h2>
                           <p className="mt-1">Загрузите или выберите группу слева для просмотра статистики.</p>
                        </div>
                    ) : groupStats ? (
                        <div className="space-y-6">
                         <h2 className="text-2xl font-bold text-gray-800">Аналитика по группе: <span className="text-primary-700">{selectedGroup}</span></h2>
                         <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
                            <StatCard title="Количество студентов" value={String(groupStats.studentCount)} note="В данной группе" />
                            <StatCard title="Средний % выполнения" value={groupStats.overallAvgCompletion} note="По всем работам" />
                            {Object.values(groupStats.avgCompletionRateByType).map((stat: { id: string; percentage: string; note: string; }) => (
                                <StatCard key={stat.id} title={`Средний % (${stat.id})`} value={stat.percentage} note={stat.note} />
                            ))}
                        </div>
                        
                        <PerformanceChart data={groupStats.performanceByTopic} />

                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                           <div className="lg:col-span-2">
                                <StudentOverviewWidget students={groupStats.studentScores} onSelectStudent={handleSelectStudentForModal} />
                           </div>
                           <div className="space-y-6">
                                <DifficultTopicsWidget topics={groupStats.difficultTopics} />
                                <GradeDistributionChart data={groupStats.gradeDistribution} />
                           </div>
                        </div>
                        </div>
                    ) : (
                         <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 bg-slate-50 rounded-lg">
                           {loading ? <p>Анализ данных...</p> : <p>Не удалось загрузить статистику для этой группы.</p>}
                        </div>
                    )}
                </main>
            </div>
            
            {/* Student Detail Modal */}
            {isModalOpen && modalStudentData && selectedStudentHash && (
                 <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex items-center justify-center p-4" onClick={closeModal}>
                    <div className="bg-slate-100 rounded-2xl shadow-2xl w-full max-w-7xl h-[95vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
                        <header className="flex items-center justify-between p-4 bg-white border-b border-gray-200 shrink-0 rounded-t-2xl">
                             <h2 className="text-xl font-bold text-gray-800">
                                Аналитика по студенту: <span className="text-primary-700">{selectedStudentHash}</span>
                             </h2>
                             <button onClick={closeModal} className="p-2 rounded-full hover:bg-gray-200">
                                 <XMarkIcon className="w-6 h-6 text-gray-600"/>
                             </button>
                        </header>
                        <main className="flex-1 overflow-y-auto p-6">
                            <StudentAnalyticsView studentData={modalStudentData} studentHash={selectedStudentHash} />
                        </main>
                    </div>
                </div>
            )}
        </div>
    );
};

export default TeacherDashboardPage;
