
import React, { useState, useCallback } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import DashboardPage from './components/DashboardPage';
import TeacherDashboardPage from './components/TeacherDashboardPage';
import GroupSelectionPage from './components/GroupSelectionPage';
import { ParsedExcelData } from './types';

const App: React.FC = () => {
  const [teacherIsAuthenticated, setTeacherIsAuthenticated] = useState<boolean>(false);
  const [files, setFiles] = useState<{ [fileName: string]: ParsedExcelData }>({});

  const handleLogin = useCallback(() => {
    setTeacherIsAuthenticated(true);
  }, []);

  const handleLogout = useCallback(() => {
    setTeacherIsAuthenticated(false);
  }, []);

  const addFile = useCallback((name: string, data: ParsedExcelData) => {
    setFiles(prevFiles => ({ ...prevFiles, [name]: data }));
  }, []);

  return (
    <HashRouter>
      <Routes>
        <Route path="/login" element={
          teacherIsAuthenticated ? <Navigate to="/teacher" /> : <LoginPage onLogin={handleLogin} />
        } />
        <Route path="/teacher" element={
          teacherIsAuthenticated ? 
            <TeacherDashboardPage 
                onLogout={handleLogout} 
                files={files}
                addFile={addFile}
            /> 
            : <Navigate to="/login" />
        } />
        <Route path="/student/dashboard" element={<DashboardPage />} />
        <Route path="/" element={<GroupSelectionPage files={files} />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </HashRouter>
  );
};

export default App;
